package design_pattern.obServer_design_pattern;

import java.util.Observer;

/**
*@作者：shaoli
*2018年9月29日下午11:43:51
* 读万卷书，行万里路
*/

public class BinaryObserver extends ObServer{

	public BinaryObserver (Subject subject){
		this.subject=subject;
		this.subject.attach(this);
	}
	
	@Override
	public void update() {
		System.out.println( "Binary String: " 
			      + Integer.toBinaryString( subject.getState() ) ); 
	}

}
