package design_pattern.obServer_design_pattern;
/**
*@作者：shaoli
*2018年9月29日下午11:49:48
* 读万卷书，行万里路
*/

public class HexaObserver extends ObServer{

	public HexaObserver(Subject subject){
	      this.subject = subject;
	      this.subject.attach(this);
	  }
	
	@Override
	public void update() {
		System.out.println( "Hex String: " 
			     + Integer.toOctalString( subject.getState() ) ); 
	}
}
